"""Deployment startup selection; owner adoption is enabled by the test VM overlay.

Owners mode keeps booting when a chain's database revision is ahead of this
image and leaves that newer schema in place. This only lets the image boot.
It does not check that the image works against the newer schema: that depends
on the migrations between the two being expand-only, which startup cannot
verify.
"""
from __future__ import annotations

import logging
import os
import re
from collections.abc import Collection
from pathlib import Path

from alembic import command
from alembic.config import Config
from alembic.script import ScriptDirectory
from alembic.script.revision import ResolutionError
from alembic.util.exc import CommandError
from sqlalchemy import inspect, text
from sqlalchemy.engine import Connection, make_url

from controlplane_db import migrations

_logger = logging.getLogger(__name__)


def _revision_missing_from_image(script: ScriptDirectory, revision: str) -> bool:
    """True only when Alembic cannot find this database revision in the image.

    ``upgrade`` reports that as ``Can't locate revision identified by '<id>'``
    with a ``ResolutionError`` cause of ``No such revision or branch``. A known
    revision, including one that is behind head, resolves and must still
    upgrade. Any other resolution error, including an ambiguous prefix, raises.
    """
    try:
        script.get_revision(revision)
    except CommandError as exc:
        cause = exc.__cause__
        missing = (
            str(exc) == f"Can't locate revision identified by '{revision}'"
            and isinstance(cause, ResolutionError)
            and str(cause).startswith(f"No such revision or branch '{revision}'")
        )
        if missing:
            return True
        raise
    return False


def _is_chain_revision(chain: str, revision: str) -> bool:
    """True for an id in this chain's ``<chain>_<NNNN>_<slug>`` format."""
    return re.fullmatch(rf'{re.escape(chain)}_\d{{4}}_[a-z0-9_]+', revision) is not None


def _require_ahead_of_image(
    chain: str,
    revision: str,
    image_head: str,
    owned_tables: Collection[str],
    tables: Collection[str],
) -> None:
    """Fail closed unless the unknown revision can be a later revision of this chain.

    Absence from the image alone does not show the database is newer. An id in
    another chain's format, a malformed id, or a schema missing tables this
    image needs stops startup. The number in the id is not compared with the
    image head's: revision numbers are not monotonic along the chain (for
    example 0062_model_lifecycle follows 0063_pending_jobs), so a number cannot
    show which side is ahead.
    """
    if not _is_chain_revision(chain, revision):
        raise ValueError(
            f'{chain}: database revision {revision} is not in this image and is not a '
            f'revision id of this chain (image head {image_head}); refusing to start'
        )
    missing = sorted(set(owned_tables) - set(tables))
    if missing:
        raise ValueError(
            f'{chain}: database revision {revision} is not in this image and the schema is '
            f'missing tables this image needs ({", ".join(missing)}); refusing to start'
        )


def _upgrade_owner_chain(
    root: Path,
    chain: str,
    connection: Connection,
    revision: str | None,
    owned_tables: Collection[str],
    tables: Collection[str],
) -> None:
    """Upgrade one owner chain unless its database revision is ahead of this image."""
    if revision is not None:
        script = ScriptDirectory.from_config(migrations._config(root, chain))
        if _revision_missing_from_image(script, revision):
            image_head = script.get_current_head()
            _require_ahead_of_image(chain, revision, image_head, owned_tables, tables)
            _logger.warning(
                'skipping %s upgrade: database revision %s is not in this image (image head %s)',
                chain,
                revision,
                image_head,
            )
            return
    command.upgrade(migrations._config(root, chain, connection), 'head')


_BOOTSTRAP_ENV = 'CONTROLPLANE_DB_BOOTSTRAP'


def _bootstrap_allowed() -> bool:
    return os.environ.get(_BOOTSTRAP_ENV, '').strip().lower() in {'1', 'true', 'yes'}


def _owners(database_url: str, root: Path | None = None, *, allow_empty: bool | None = None) -> None:
    if root is None:
        root = migrations._ROOT
    registry = migrations._registry(root)
    # Build the events source index concurrently before the schema
    # transaction. events_0054 refuses a blocking build on a published log.
    if migrations._prepare_pending_event_source_index(database_url, root):
        _logger.info('prepared the event source index concurrently before owner upgrades')
    engine = migrations._engine(database_url)
    try:
        with engine.begin() as connection:
            connection.execute(text("SELECT pg_advisory_xact_lock(hashtext('controlplane-owner-migrations'))"))
            versions = migrations._versions(connection, root)
            legacy = migrations._legacy_revision(connection)
            tables = set(inspect(connection).get_table_names(schema='public'))
            current_tables = {table for entry in registry['chains'].values() for table in entry['tables']}
            expected = {table for entry in registry['chains'].values()
                        for table in entry.get('baseline_tables', entry['tables'])}
            if legacy is not None and legacy != registry['source_revision']:
                raise ValueError('upgrade the old chain to 0053_onboarding_runs before test reload')
            if all(value is None for value in versions.values()):
                if legacy is not None:
                    if not expected <= tables:
                        raise ValueError('mixed-chain database is missing baseline tables')
                    for chain, entry in registry['chains'].items():
                        command.stamp(migrations._config(root, chain, connection), entry['baseline'])
                elif current_tables.intersection(tables):
                    raise ValueError('unversioned existing tables require reviewed baseline adoption')
                elif not (_bootstrap_allowed() if allow_empty is None else allow_empty):
                    # An empty database is what a container recreated on an empty
                    # data directory looks like. Building a fresh schema here would
                    # hide the data loss, so require an explicit bootstrap.
                    raise ValueError(
                        f'database has no schema and no migration history; refusing to create one. '
                        f'Restore the data directory or a backup, or set {_BOOTSTRAP_ENV}=1 for a new deployment'
                    )
            elif any(value is None for value in versions.values()):
                raise ValueError('partial owner adoption requires review before test reload')
            for chain in migrations._ORDER:
                _upgrade_owner_chain(
                    root, chain, connection, versions[chain], registry['chains'][chain]['tables'], tables
                )
    finally:
        engine.dispose()


def main() -> int:
    mode = os.environ.get('CONTROLPLANE_MIGRATION_MODE', 'legacy')
    if mode == 'owners':
        url = os.environ.get('DATABASE_URL')
        if not url:
            raise ValueError('DATABASE_URL is required for owner adoption')
        _owners(url)
    elif mode == 'legacy':
        ini = Path(__file__).with_name('alembic.ini')
        command.upgrade(Config(str(ini)), 'head')
        # The mixed history is frozen; apply the forward-only security repair
        # after it, without changing historical revisions or baseline hashes.
        from controlplane_db._share_lookup_hardening import apply
        url = os.environ.get("DATABASE_URL", "postgresql+psycopg://controlplane:controlplane123@localhost:5432/controlplane")
        engine = migrations._engine(make_url(url).set(drivername="postgresql+psycopg").render_as_string(hide_password=False))
        try:
            with engine.begin() as connection:
                apply(connection)
        finally:
            engine.dispose()
    else:
        raise ValueError('CONTROLPLANE_MIGRATION_MODE must be legacy or owners')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
