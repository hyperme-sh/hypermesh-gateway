"""HS256 JWT minted after a verified tenant switch (not Keycloak, not API-key).

Same shared secret as the API-key exchange token; different issuer and
``spanopticon_auth`` so mint/consume cannot be confused with purpose grants.
"""

from __future__ import annotations

import asyncio
import time
import uuid
from typing import Any

import jwt
from jwt import InvalidTokenError

from controlplane_identity.account_lifecycle import require_open_account
from controlplane_identity.configuration import LEGACY_SMOKE_SESSION_CLAIM, settings, api_key_exchange_secrets

ISSUER = "https://spanopticon.internal/tenant-session"
ALG = "HS256"
TTL_SECONDS = 900
SPANOPTICON_AUTH = "tenant_session"


def is_smoke_session(claims: dict[str, Any] | None) -> bool:
    """Classify verified session claims independently of deployment configuration."""
    return isinstance(claims, dict) and (
        claims.get("smoke_session") is True
        or claims.get(LEGACY_SMOKE_SESSION_CLAIM) is True
    )


def mint_tenant_session_jwt(
    *,
    claims: dict[str, Any],
    tenant_id: uuid.UUID,
    extra_roles: list[str] | None = None,
    extra_permissions: list[str] | None = None,
) -> str:
    """Short-lived JWT so ``get_current_tenant`` sees tenant context."""
    if claims.get("azp") == "hypermesh-host-setup":
        raise ValueError("host setup requires a purpose-bound session")
    now = int(time.time())
    roles: list[str] = []
    ra = claims.get("realm_access")
    if isinstance(ra, dict):
        raw_roles = ra.get("roles")
        if isinstance(raw_roles, list):
            roles.extend(str(r) for r in raw_roles if str(r).strip())
    for role in extra_roles or []:
        name = str(role).strip()
        if name and name not in roles:
            roles.append(name)

    groups = claims.get("groups")
    if groups is None:
        groups = claims.get("group")
    if isinstance(groups, str) and groups.strip():
        groups_out: list[str] | str = groups.strip()
    elif isinstance(groups, list):
        groups_out = [str(g).strip() for g in groups if str(g).strip()]
    else:
        groups_out = []

    payload: dict[str, Any] = {
        "sub": str(claims.get("sub") or ""),
        "iss": ISSUER,
        "azp": str(claims.get("azp") or "controlplane-frontend"),
        "iat": now,
        "exp": now + TTL_SECONDS,
        "spanopticon_auth": SPANOPTICON_AUTH,
        "tenant_id": str(tenant_id),
        "https://spanopticon.dev/tenant_id": str(tenant_id),
        "realm_access": {"roles": roles},
        "groups": groups_out,
        "scope": str(claims.get("scope") or "openid"),
    }
    permissions: list[str] = []
    raw_permissions = claims.get("permissions")
    if isinstance(raw_permissions, list):
        permissions.extend(str(item).strip() for item in raw_permissions if str(item).strip())
    for perm in extra_permissions or []:
        name = str(perm).strip()
        if name and name not in permissions:
            permissions.append(name)
    payload["permissions"] = permissions
    host_org_id = claims.get("host_org_id")
    if host_org_id is not None and str(host_org_id).strip():
        payload["host_org_id"] = str(host_org_id)

    email = claims.get("email") or claims.get("preferred_username") or claims.get("username")
    if email:
        payload["email"] = str(email)
    if claims.get("preferred_username"):
        payload["preferred_username"] = str(claims["preferred_username"])
    if claims.get("account_type") in {"human", "service"}:
        payload["account_type"] = claims["account_type"]
    if claims.get("amr") is not None:
        payload["amr"] = claims["amr"]
    if is_smoke_session(claims) or claims.get(settings.smoke_session_claim) is True:
        # Authorization is invariant. The configured marker is only compatibility
        # metadata; older API-key processes still see their fixed legacy marker.
        payload["smoke_session"] = True
        payload[LEGACY_SMOKE_SESSION_CLAIM] = True
        payload[settings.smoke_session_claim] = True
    secret = next(iter(api_key_exchange_secrets()), None)
    if not secret:
        raise RuntimeError("API_KEY_EXCHANGE_JWT_SECRET is unset or is a published default")
    return jwt.encode(
        payload,
        secret,
        algorithm=ALG,
    )


def try_decode_tenant_session_jwt(token: str) -> dict[str, Any] | None:
    """Return claims if token is a valid tenant-session JWT; else None."""
    for secret in api_key_exchange_secrets():
        if not secret:
            continue
        try:
            payload = jwt.decode(
                token,
                secret,
                algorithms=[ALG],
                issuer=ISSUER,
                options={"require": ["exp", "sub", "iss"]},
            )
        except InvalidTokenError:
            continue
        break
    else:
        return None
    if payload.get("azp") == "hypermesh-host-setup" or payload.get("spanopticon_auth") != SPANOPTICON_AUTH:
        return None
    try:
        require_open_account(payload)
    except InvalidTokenError:
        return None
    return payload


HOST_SETUP_ISSUER = "https://spanopticon.internal/host-setup"
HOST_SETUP_AUDIENCE = "hypermesh-host-setup"


def mint_host_setup_session(*, claims: dict[str, Any], tenant_id: uuid.UUID) -> str:
    """Identity and tenant only; never copy account roles or permissions."""
    if claims.get("azp") != HOST_SETUP_AUDIENCE or not claims.get("sub"):
        raise ValueError("host setup identity required")
    secret = next(iter(api_key_exchange_secrets()), None)
    if not secret:
        raise RuntimeError("host setup signing key unavailable")
    now = int(time.time())
    return jwt.encode({
        "iss": HOST_SETUP_ISSUER, "aud": HOST_SETUP_AUDIENCE,
        "azp": HOST_SETUP_AUDIENCE, "purpose": "host_setup",
        "sub": str(claims["sub"]), "email": str(claims.get("email") or ""),
        "tenant_id": str(tenant_id), "iat": now, "exp": now + TTL_SECONDS,
    }, secret, algorithm=ALG)


def try_decode_host_setup_session(token: str) -> dict[str, Any] | None:
    for secret in api_key_exchange_secrets():
        if not secret:
            continue
        try:
            payload = jwt.decode(
                token, secret, algorithms=[ALG], issuer=HOST_SETUP_ISSUER,
                audience=HOST_SETUP_AUDIENCE,
                options={"require": ["exp", "sub", "iss", "aud", "tenant_id"]},
            )
        except InvalidTokenError:
            continue
        break
    else:
        return None
    if payload.get("purpose") != "host_setup" or payload.get("azp") != HOST_SETUP_AUDIENCE:
        return None
    try:
        require_open_account(payload)
    except InvalidTokenError:
        return None
    return payload


async def try_decode_tenant_session_jwt_async(token: str) -> dict[str, Any] | None:
    """Validate a tenant session without blocking the caller's event loop."""
    return await asyncio.to_thread(try_decode_tenant_session_jwt, token)


async def try_decode_host_setup_session_async(token: str) -> dict[str, Any] | None:
    """Validate a setup-only session with the caller's verification context."""
    return await asyncio.to_thread(try_decode_host_setup_session, token)
